return {
    name = "hunterHunted",
    version = "1.0.1",
    author = "KaiB85",
    title = "Hunter Hunted",
    description = "Hunter vs Hunted multiplayer gamemode for BeamNG.drive",
    gameVersion = "0.36.0.0"
}